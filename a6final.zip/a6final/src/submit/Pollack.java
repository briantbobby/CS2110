package submit;

import java.util.HashSet;
import java.util.List;

import game.FindState;
import game.Finder;
import game.Node;
import game.NodeStatus;
import game.ScramState;
import game.Tile;

/** Student solution for two methods. */
public class Pollack extends Finder {

    /** Get to the orb in as few steps as possible. <br>
     * Once you get there, you must return from the function in order to pick it up. <br>
     * If you continue to move after finding the orb rather than returning, it will not count.<br>
     * If you return from this function while not standing on top of the orb, it will count as <br>
     * a failure.
     *
     * There is no limit to how many steps you can take, but you will receive<br>
     * a score bonus multiplier for finding the orb in fewer steps.
     *
     * At every step, you know only your current tile's ID and the ID of all<br>
     * open neighbor tiles, as well as the distance to the orb at each of <br>
     * these tiles (ignoring walls and obstacles).
     *
     * In order to get information about the current state, use functions<br>
     * state.currentLoc(), state.neighbors(), and state.distanceToOrb() in FindState.<br>
     * You know you are standing on the orb when distanceToOrb() is 0.
     *
     * Use function state.moveTo(long id) in FindState to move to a neighboring<br>
     * tile by its ID. Doing this will change state to reflect your new position.
     *
     * A suggested first implementation that will always find the orb, but <br>
     * likely won't receive a large bonus multiplier, is a depth-first walk. <br>
     * Some modification is necessary to make the search better, in general. */
    HashSet<Long> visited= new HashSet<>();

    @Override
    public void findOrb(FindState state) {
        dfsWalk(state);
        return;
    }

    /** The Walker is standing on a Node u (say) given by State s. If node u <br>
     * contains the orb, return. Visit every node reachable along paths of <br>
     * unvisited nodes from node u, stopping early when the Orb is encountered. <br>
     * If the orb is encountered, end with walker standing on the Orb. If the <br>
     * orb is not encountered, end with walker standing on u. <br>
     * Precondition: u is unvisited. */
    private void dfsWalk(FindState state) {
        if (state.distanceToOrb() == 0) return;
        long u= state.currentLoc();
        visited.add(u);
        Heap<NodeStatus> neighbors= new Heap<>(false);
        for (NodeStatus w : state.neighbors()) {
            neighbors.add(w, w.getDistanceToTarget());
        }
        while (neighbors.size() > 0) {
            NodeStatus w= neighbors.poll();
            long wId= w.getId();
            if (!visited.contains(wId)) {
                state.moveTo(wId);
                dfsWalk(state);
                if (state.distanceToOrb() == 0) return;
                state.moveTo(u);
            }
        }
    }

    /** Pres Pollack is standing at a node given by parameter state.<br>
     *
     * Get out of the cavern before the ceiling collapses, trying to collect as <br>
     * much gold as possible along the way. Your solution must ALWAYS get out <br>
     * before time runs out, and this should be prioritized above collecting gold.
     *
     * You now have access to the entire underlying graph, which can be accessed <br>
     * through parameter state. <br>
     * state.currentNode() and state.getExit() will return Node objects of interest, and <br>
     * state.allNodes() will return a collection of all nodes on the graph.
     *
     * The cavern will collapse in the number of steps given by <br>
     * state.stepsLeft(), and for each step this number is decremented by the <br>
     * weight of the edge taken. <br>
     * Use state.stepsLeft() to get the time still remaining, <br>
     * Use state.moveTo() to move to a destination node adjacent to your current node.<br>
     * Do not call state.grabGold(). Gold on a node is automatically picked up <br>
     * when the node is reached.<br>
     *
     * The method must return from this function while standing at the exit. <br>
     * Failing to do so before time runs out or returning from the wrong <br>
     * location will be considered a failed run.
     *
     * You will always have enough time to scram using the shortest path from the <br>
     * starting position to the exit, although this will not collect much gold. <br>
     * For this reason, using the shortest path method to calculate the shortest <br>
     * path to the exit is a good starting solution */

    @Override
    public void scram(ScramState state) {
        optimizedGoldPath(state);
        optimizedGoToExit(state);
        return;
    }

    /** Procedure finds the next best node based on its distance and gold, <br>
     * travels to that node (if it is possible to do so and get to the exit <br>
     * given the amount of steps left), and then calls itself again until <br>
     * the either 1) there are no more nodes with gold on them, or 2) the <br>
     * next best node is not reachable given the number of steps left. <br>
     * This procedure takes in a ScramState object. */
    private void optimizedGoldPath(ScramState state) {
        Node next= bestNextNode(state);
        if (next == null) return;
        List<Node> pathToNode= Path.shortest(state.currentNode(), next);
        List<Node> pathToExit= Path.shortest(next, state.getExit());
        if (state.stepsLeft() < Path.pathSum(pathToNode) + Path.pathSum(pathToExit)) return;
        traversePath(state, pathToNode);
        optimizedGoldPath(state);

    }

    /** This method takes in a ScramState and returns a node on the board. To <br>
     * do this it generates a collection of all the nodes and then a HashSet of <br>
     * all the nodes with any amount of gold on the associated tile. It then <br>
     * generates a min-heap of the nodes based on their distance and their gold <br>
     * values, and polls this heap to return the node. */
    private Node bestNextNode(ScramState state) {
        HashSet<Node> hasGold= new HashSet<>();
        for (Node n : state.allNodes()) {
            Tile nTile= n.getTile();
            if (nTile.gold() > 0) {
                hasGold.add(n);
            }
        }
        Heap<Node> rankedNodes= new Heap<>(false);
        for (Node w : hasGold) {
            int distance= Path.pathSum(Path.shortest(state.currentNode(), w));
            int gold= w.getTile().gold();
            rankedNodes.add(w, Math.pow(distance, 2.85) / Math.pow(gold, 3));
        }
        if (rankedNodes.size() == 0) return null;
        return rankedNodes.poll();

    }

    /** This procedure traverses a path, given by list of Nodes path, by <br>
     * calling state.moveTo(path element) for each path element excluding <br>
     * the very first. It takes in a ScramState object and a list of Nodes. <br>
     * Precondition: state.currentNode() = path.get(0) */
    private void traversePath(ScramState state, List<Node> path) {
        for (int i= 1; i < path.size(); i++ ) {
            state.moveTo(path.get(i));
        }
        return;
    }

    /** This procedure traverses the shortest path from the current Node to <br>
     * the exit. However, it will also traverse out to (and back from) direct <br>
     * neighbors of the Nodes along the shortest path if 1) doing so does not <br>
     * jeopardize returning to the exit in the allotted number of steps <br>
     * and 2) if there is gold on said neighbor. This procedure takes in a <br>
     * ScramState object. */
    private void optimizedGoToExit(ScramState state) {
        List<Node> shortPath= Path.shortest(state.currentNode(), state.getExit());
        for (int i= 1; i < shortPath.size() - 1; i++ ) {
            state.moveTo(shortPath.get(i));
            Node current= state.currentNode();
            int stepsLeft= state.stepsLeft();
            int stepsToExit= Path.pathSum(shortPath.subList(i, shortPath.size()));
            for (Node n : current.getNeighbors()) {
                if (n.getTile().gold() > 0 && !n.equals(shortPath.get(i + 1))) {
                    int stepsToNeighbor= current.getEdge(n).length();
                    if (2 * stepsToNeighbor + stepsToExit < stepsLeft) {
                        state.moveTo(n);
                        state.moveTo(current);
                        stepsLeft= stepsLeft - 2 * stepsToNeighbor;
                    }
                }
            }
        }
        state.moveTo(shortPath.get(shortPath.size() - 1));
        return;
    }
}
